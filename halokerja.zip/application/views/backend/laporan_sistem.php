<div id="isi">
<div id="body_nav">
				<a href="<?php echo base_url() ?>cpanel/laporan_main" class="nav"> Index</a>
				<a href="<?php echo base_url() ?>cpanel/laporan_fast_slow" class="nav"> Fast/Slow Moving</a>
				<a href="<?php echo base_url() ?>cpanel/laporan_high_low" class="nav"> Hight/low Profit</a>
				<a href="<?php echo base_url() ?>cpanel/laporan_operational" class="nav"> Operational Profit</a>
				<a href="<?php echo base_url() ?>cpanel/laporan_cost" class="nav"> Cost Calculation</a>
			</div>
<div id="judul_konten">
	<h2>Laporan-Laporan</h2>
</div>
<div id="content">
<br />
<br />
<a href="<?php echo base_url() ?>cpanel/laporan_peak_time" class="nav">Laporan Peak Time</a>
</div>
</div>