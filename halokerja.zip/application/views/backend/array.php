<?php
	print_r($tes);
?>