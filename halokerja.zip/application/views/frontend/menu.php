<div id="article">
<div id="carikonten">
<h3 style="text-align:center;">List Menu</h3>
<hr /><br />
<ul>
<li><a href="#cofee">Coffe</a></li>
<li><a href="#makanan">Makanan</a></li>
<li><a href="#mie">Mie</a></li>
</ul>
</div>
<h1>Our Menu</h1>
<hr />
<div id="cofee">
<h2>Coffe</h2>
<div class="men">
Kopi Luak<br>
RP 100.000<br>
<img src="<?php echo base_url()?>menu/kopi_luak.jpg"><br>
Mahalnya mencekek leher
</div>

<div class="men">
Kopi Luak<br>
RP 100.000<br>
<img src="<?php echo base_url()?>menu/kopi_luak.jpg"><br>
Mahalnya mencekek leher
</div>

<div class="men">
Kopi Luak<br>
RP 100.000<br>
<img src="<?php echo base_url()?>menu/kopi_luak.jpg"><br>
Mahalnya mencekek leher
</div>

<div class="men">
Kopi Luak<br>
RP 100.000<br>
<img src="<?php echo base_url()?>menu/kopi_luak.jpg"><br>
Mahalnya mencekek leher
</div>

<div class="men">
Kopi Luak<br>
RP 100.000<br>
<img src="<?php echo base_url()?>menu/kopi_luak.jpg"><br>
Mahalnya mencekek leher
</div>

<div class="clearfix"></div>
</div>
<div id="makanan">
<h2>Makanan</h2>

<div class="men">
Nasi Goreng<br>
RP 10.000<br>
<img src="<?php echo base_url()?>menu/makanan_nasgor.jpg"><br>
Bumbu kecap bango
</div>

<div class="clearfix"></div>
</div>
<div id="mie">
<h2>Mie</h2>

<div class="men">
Mie Reman<br>
RP 10.000<br>
<img src="<?php echo base_url()?>menu/mie_reman.jpg"><br>
Indomie tambah cabe
</div>

<div class="clearfix"></div>
</div>
</div>