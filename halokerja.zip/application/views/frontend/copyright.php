<div id="article">
<h2>Our Team</h2>
<table class="form" style="width:100%;text-align:center;">
<tr><td>Irvan Firmansyah</td><td>Andhika Agung Antrada</td><td>
<tr><td>120110110098</td><td>120110120091</td><td>
</table>
</div>