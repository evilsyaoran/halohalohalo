<div id="isi">
<h2 id="judullogin">Ganti Password</h2>
<div class="clearfix"></div>
<br>
<hr />
<br>
					<form method="POST" action="<?=base_url()?>user/php_ganti_password">
					<input id="luser" type="pass1" placeholder="Password lama" name="passowrdl" class="login"><br />
					<input id="luser" type="pass1" placeholder="Password" name="passowrd1" class="login"><br />
					<input id="lpass" type="pass2" placeholder="Confirm Passowrd" name="password2" class="login"><br /><br />
					<input id="lsubmit" type="submit" class="button" value="Submit">
					</form>
</div>