<div id="article">
<h1>About us</h1>
<hr />
<br />

<p>Banyak nya cafe di bandung mengharuskan kita lebih berinovasi dan variatif dikarenakan banyaknya penawaran cafe dibandung memaksa kita untuk mempunyai sesuatu yang beda, pada prinsipnya setiap orang pergi ke cafe untuk menikmati makanan yang enak dan biaya yang serendah-rendahnya, namun konsep itu sudah dimiliki terlalu banyak cafe dibandung, selain itu orang orang pergi ke cafe yang memiliki wifi/internet yang cepat untuk melakukan aktivitas, namun itu juga sudah terlalu banyak diterapkan di cafe di bandung. semakin berkembangnya zaman dan semakin berkembangnya juga permintaan dan selera konsumen. di era sekarang ini orang-orang tidak pergi ke cafe hanya untuk makan ataupun internetan tetapi kemabali lagi ke prinsip awal yaitu kenyamanan visual dan kenyamanan berada di cafe itu.
</p><br />
<p>
<p>Berdasarkan an?lisis kita diatas maka kita mempunyai semua kelebihan kelebihan cafe lain di package dalam satu cafe di ?pasific cafe? yang menawarkan tempat makan, tempat nongkrong, tempat belajar, tempat main, tempat kumpul, santai-santai, multifunction place dengan low price with internet dan design interior minimalis dari budaya barat yang dikembangkan menjadi modern yang dapat membuat konsumen tertarik dan penasaran dan ini adalah salah satu senjata kita untuk menarik konsumen karena dengan design cafe dan design interior tersebut kita akan menarik konsumen untuk mengabadikannya design tersebut dengan sebuah dokumentasi berupa foto atau lainnya yang dapat membuat kita memotong anggaran pemasaran karena dengan sendirnya konsumen akan mempublikasikan cafe kita tersebut.
</p><br />
<p>
<p>Pasific Cafe ini merupakan salah satu cafe pertama di Bandung yang menciptakan konsep dimana orang orang bisa menikmati makanan dan minuman yang murah dan terjangkau dengan view dan kenyamanan yang dicari oleh orang orang sekaligus menawarkan koneksi internet yang cepat, sehingga memungkinkan untuk orang orang datang ke pasific cafe untuk nongkrong , bisnis, belajar, ataupun mengerjakan tugas.
</p><br />
<p>Sebagai  ide  ini, Paific cafe sudah berkembang  dan memilik tiga cabang di kota Bandung dan akan berkembang membuka cabang diluar bandung. Kemajuan usaha ini didukung dengan strategi manajemen yang sangat baik sehingga sampai sekarang pasific cafe telah menjadi pilihan banyak generasi muda serta tetap menjadi unggulan dimana sekarang banyak sekali pesaing ? pesain yang membuat cafe dengan ide serupa Tetapi Pasific cafe lah yang menjadi pilihan masyarakat sekarang yang semakin mengikuti tren masa kini dan di fasilitasi dengan teknologi yang berkembang pesat.
</p><br />
Pasific Cafe memiliki Cabang di:
</p><br />
<p>
<ul>
   <li>Jalan Dago Pakar</li>
   <li> Jalan Braga</li>
    <li>Jalan Sukajadi (PVJ Bandung)</li>
 </ul>